browser.devtools.panels.create(
  'Edit & Resend',
  'icons/icon16.png',
  'panel.html'
);
